from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from .models import *
from .forms import EventForm, Calendar
from datetime import datetime, timedelta, date
from django.shortcuts import render, get_object_or_404
from django.views import generic
from django.urls import reverse, reverse_lazy
from django.utils.safestring import mark_safe
from django.views.generic import DeleteView, ListView
import calendar


class CalendarView(generic.ListView):
    model = Event
    template_name = 'cal_app/calendar.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        d = get_date(self.request.GET.get('month', None))
        cal = Calendar(d.year, d.month)
        html_cal = cal.formatmonth(self.request.user,withyear=True)
        context['calendar'] = mark_safe(html_cal)
        context['prev_month'] = prev_month(d)
        context['next_month'] = next_month(d)
        return context

def get_date(req_month):
    if req_month:
        year, month = (int(x) for x in req_month.split('-'))
        return date(year, month, day=1)
    return datetime.today()

def prev_month(d):
    first = d.replace(day=1)
    prev_month = first - timedelta(days=1)
    month = 'month=' + str(prev_month.year) + '-' + str(prev_month.month)
    return month

def next_month(d):
    days_in_month = calendar.monthrange(d.year, d.month)[1]
    last = d.replace(day=days_in_month)
    next_month = last + timedelta(days=1)
    month = 'month=' + str(next_month.year) + '-' + str(next_month.month)
    return month

def event(request, event_id=None):
	instance = Event()
	if event_id:
		instance = get_object_or_404(Event, pk=event_id)
	else:
		instance = Event()

	form = EventForm(request.POST or None, instance=instance)
	if request.POST and form.is_valid():
		fs = form.save(commit=False)# save form with our owner.
		fs.event_owner = request.user# sets the current loged in user as owner.
		fs.save() # saves for with all parts
		return HttpResponseRedirect(reverse('calendar'))
	return render(request, 'cal_app/event.html', {'form': form})

class DeleteEventView(DeleteView):
    model = Event
    template_name = 'cal_app/delete_event.html'
    success_url = reverse_lazy('home')

def eventListView(request):
    current_user = request.user
    user_events = current_user.event_set.all()
    return render(request, 'cal_app/event_list.html', {'events': user_events})

def deleteEventView(request, pk):
    event = get_object_or_404(Event, pk=pk)
    event.delete()
    return redirect('../../')

