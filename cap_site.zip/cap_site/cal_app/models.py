from django.db import models
from django.urls import reverse
from django.contrib.auth.models import User

class Event(models.Model):
	title = models.CharField(max_length = 200)
	description = models.TextField()
	start_time = models.DateTimeField()
	end_time = models.DateTimeField()
	event_owner = models.ForeignKey(User, on_delete=models.CASCADE)
	# event_owner = models.CharField(max_length = 30)

	@property
	def get_html_url(self):
		url = reverse('event_edit', args=(self.id,))
		return f'<a href="{url}"> {self.title} </a>'