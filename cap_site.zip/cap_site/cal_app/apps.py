from django.apps import AppConfig


class CalAppConfig(AppConfig):
    name = 'cal_app'
