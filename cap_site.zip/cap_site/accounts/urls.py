from django.urls import path
from . import views
from .views import UserRegisterView, UserEditView, PasswordsChangeView
from django.contrib.auth import views as auth_views
# from django.contrib.auth.views import password_reset, password_reset_done
from django.contrib.auth.views import PasswordResetView, PasswordResetDoneView, PasswordResetConfirmView
# from .views import UserRegisterView
# UserEditView

urlpatterns = [
	path('register/', UserRegisterView.as_view(), name = 'register'),
	# path('edit_profile/', UserEditView.as_view(), name = 'edit_profile'),
	#
    # path('profile/edit/', views.edit_profile, name = "edit_profile"),
    path('edit_profile/', UserEditView.as_view(), name = 'edit_profile'),
    # path('profile/change-password/', views.change_password, name = "change_password"),
    path('password/', PasswordsChangeView.as_view(template_name='registration/change_password.html'), name= "change_password"),
    path('password-reset/', 
    	PasswordResetView.as_view(template_name='registration/password_reset.html'), name='password_reset'),
	path('password-reset/done/', PasswordResetDoneView.as_view(template_name='registration/password_reset_done.html'), name="password_reset_done"),
	path('password-reset-confirm/<uidb64>/<token>/', PasswordResetConfirmView.as_view(template_name='registration/password_reset_confirm.html'), name="password_reset_confirm"),
]	